package com.oracle.appjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppjavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
